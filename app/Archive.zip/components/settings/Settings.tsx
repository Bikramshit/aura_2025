import React from 'react'
import DashboardComponent from '../Dashboard/DashboardComponent'

function Settings() {
  return (
    <>
   
   <DashboardComponent title='Settings'>
    <>
    
    </>
   </DashboardComponent>
    
    </>
  )
}

export default Settings