import React from 'react'

function Prize() {
  return (
    <div>Prize</div>
  )
}

export default Prize