import React from 'react'

function Crew() {
  return (
    <div>Crew</div>
  )
}

export default Crew